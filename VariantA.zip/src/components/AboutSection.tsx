"use client";

import { useEffect, useRef } from "react";

const features = [
  { icon: "🏗️", title: "Собственное производство", desc: "Клеёный брус, каркасные панели, фахверк — всё изготавливаем сами. Никаких посредников — только прямая поставка." },
  { icon: "📐", title: "Проектирование под вас", desc: "Технический специалист разработает проект с нуля или адаптирует готовый. Приходите с идеей — уйдёте с планом." },
  { icon: "🏠", title: "500+ реальных объектов", desc: "Не 3D-рендеры — живые дома с хозяевами. Каждый можно посетить лично. Это наша главная реклама." },
  { icon: "🛡️", title: "Гарантия 5 лет", desc: "60 месяцев гарантии — это наша уверенность в своей работе. Если что-то пойдёт не так — приедем и исправим." },
  { icon: "📦", title: "База стройматериалов", desc: "Собственное снабжение от производителей. Дешевле, быстрее, надёжнее — экономим ваши деньги уже на этапе закупки." },
  { icon: "🤝", title: "Персональный менеджер", desc: "Один человек ведёт вас от первого звонка до ключей. Всегда на связи, всегда в теме вашего проекта." },
];

export default function AboutSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const imgRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px -40px 0px" }
    );
    sectionRef.current?.querySelectorAll(".reveal-up, .reveal-left, .reveal-right, .clip-reveal").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  // 3D tilt on image
  useEffect(() => {
    const el = imgRef.current;
    if (!el) return;
    const handleMove = (e: MouseEvent) => {
      const rect = el.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width - 0.5;
      const y = (e.clientY - rect.top) / rect.height - 0.5;
      el.style.transform = `perspective(800px) rotateY(${x * 12}deg) rotateX(${-y * 8}deg) scale(1.02)`;
    };
    const handleLeave = () => { el.style.transform = "perspective(800px) rotateY(0deg) rotateX(0deg) scale(1)"; };
    el.addEventListener("mousemove", handleMove);
    el.addEventListener("mouseleave", handleLeave);
    return () => {
      el.removeEventListener("mousemove", handleMove);
      el.removeEventListener("mouseleave", handleLeave);
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      id="about"
      style={{ padding: "130px 0", position: "relative", background: "var(--color-bg)", overflow: "hidden" }}
    >
      <div className="grid-decoration" />

      {/* Glow orb */}
      <div className="glow-orb" style={{
        width: "500px", height: "500px",
        background: "radial-gradient(circle, rgba(200,164,90,0.06) 0%, transparent 70%)",
        top: "20%", left: "-10%",
      }} />

      <div style={{ maxWidth: "1400px", margin: "0 auto", padding: "0 24px" }}>

        {/* Top: heading + image */}
        <div style={{
          display: "grid", gridTemplateColumns: "1fr 1fr",
          gap: "80px", alignItems: "center", marginBottom: "100px",
        }} className="about-top-grid">

          {/* Left text */}
          <div className="reveal-left">
            <div className="tag-pill" style={{ marginBottom: "24px" }}>О компании</div>
            <h2 style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(32px, 4.5vw, 60px)",
              fontWeight: 700, lineHeight: 1.08,
              color: "#f5f0e8", marginBottom: "28px",
            }}>
              Более 30 лет
              <br />
              <span className="gold-text">безупречного</span>
              <br />
              строительства
            </h2>

            <div className="section-divider" style={{ marginBottom: "28px" }} />

            <p style={{ color: "rgba(245,240,232,0.6)", lineHeight: 1.85, fontSize: "16px", marginBottom: "24px" }}>
              С 1992 года строим дома, в которых людям хочется жить.
              Прошли путь от небольшой бригады до застройщика с собственным
              производством, базой материалов и сотнями профессионалов.
            </p>
            <p style={{ color: "rgba(245,240,232,0.6)", lineHeight: 1.85, fontSize: "16px", marginBottom: "44px" }}>
              Наша главная реклама — готовые объекты, которые вы можете
              посетить лично. Мы не обещаем красивого рендера — мы показываем
              реальные дома.
            </p>

            {/* Trust badges */}
            <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "44px" }}>
              {[
                "Строим точно в срок — зафиксировано в договоре",
                "Цена при сдаче = цена в договоре, без сюрпризов",
                "Онлайн-отчёты с объекта — видите стройку из любой точки",
              ].map((text, i) => (
                <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: "12px" }}>
                  <div style={{
                    width: "20px", height: "20px", flexShrink: 0,
                    border: "1px solid var(--color-accent)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    color: "var(--color-accent)", fontSize: "11px", fontWeight: 700, marginTop: "1px",
                  }}>✓</div>
                  <span style={{ fontSize: "14px", color: "rgba(245,240,232,0.65)", lineHeight: 1.6 }}>{text}</span>
                </div>
              ))}
            </div>

            <a href="https://zodkam.ru/about/" target="_blank" rel="noopener noreferrer" className="btn-gold">
              Подробнее о компании
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M5 12h14M12 5l7 7-7 7"/>
              </svg>
            </a>
          </div>

          {/* Right image with 3D tilt */}
          <div className="reveal-right" style={{ position: "relative" }}>
            <div
              ref={imgRef}
              className="tilt-card"
              style={{
                position: "relative",
                transition: "transform 0.15s ease",
                transformStyle: "preserve-3d",
              }}
            >
              {/* Main image */}
              <div style={{ position: "relative", paddingBottom: "115%", overflow: "hidden" }}>
                <img
                  src="https://images.pexels.com/photos/7031604/pexels-photo-7031604.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700"
                  alt="Современный дом Зодчий"
                  style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }}
                />
                <div style={{
                  position: "absolute", inset: 0,
                  background: "linear-gradient(to bottom, transparent 50%, rgba(8,8,8,0.7) 100%)",
                }} />
                {/* Shine effect */}
                <div style={{
                  position: "absolute", inset: 0,
                  background: "linear-gradient(135deg, rgba(200,164,90,0.12) 0%, transparent 50%)",
                  pointerEvents: "none",
                }} />
              </div>

              {/* Counter badge */}
              <div className="counter-badge" style={{
                position: "absolute", bottom: "-24px", left: "-24px",
                zIndex: 10,
              }}>
                <div style={{ fontSize: "36px", fontWeight: 900, lineHeight: 1 }}>500+</div>
                <div style={{ fontSize: "11px", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", marginTop: "4px" }}>домов сдано</div>
              </div>

              {/* Floating card top right */}
              <div style={{
                position: "absolute", top: "-20px", right: "-20px",
                background: "rgba(8,8,8,0.95)",
                border: "1px solid rgba(200,164,90,0.3)",
                padding: "16px 20px",
                zIndex: 10,
                minWidth: "160px",
              }}>
                <div style={{ fontSize: "22px", fontWeight: 900, color: "var(--color-accent)", fontFamily: "'Playfair Display', serif" }}>30+</div>
                <div style={{ fontSize: "11px", color: "rgba(245,240,232,0.5)", letterSpacing: "0.1em", textTransform: "uppercase" }}>лет опыта</div>
              </div>

              {/* Decorative border */}
              <div style={{
                position: "absolute", top: "12px", left: "12px", right: "12px", bottom: "12px",
                border: "1px solid rgba(200,164,90,0.15)", pointerEvents: "none", zIndex: 2,
              }} />
            </div>
          </div>
        </div>

        {/* Features grid */}
        <div className="reveal-up" style={{ marginBottom: "0" }}>
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap: "1px",
            background: "rgba(200,164,90,0.08)",
          }} className="features-grid">
            {features.map((f, i) => (
              <div
                key={i}
                className="feature-card reveal-up"
                style={{ transitionDelay: `${i * 0.08}s`, background: "var(--color-bg)", position: "relative", overflow: "hidden" }}
              >
                {/* Background icon */}
                <div className="feature-icon-bg">{f.icon}</div>

                <div style={{
                  width: "48px", height: "48px",
                  background: "rgba(200,164,90,0.1)",
                  border: "1px solid rgba(200,164,90,0.2)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: "22px", marginBottom: "20px",
                }}>{f.icon}</div>

                <h3 style={{
                  fontSize: "16px", fontWeight: 700, color: "#f5f0e8",
                  marginBottom: "12px", letterSpacing: "0.01em",
                }}>{f.title}</h3>

                <p style={{
                  fontSize: "14px", color: "rgba(245,240,232,0.5)", lineHeight: 1.75,
                }}>{f.desc}</p>

                {/* Corner accent */}
                <div style={{
                  position: "absolute", bottom: 0, right: 0,
                  width: "40px", height: "40px",
                  background: "linear-gradient(135deg, transparent 50%, rgba(200,164,90,0.1) 50%)",
                }} />
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 900px) {
          .about-top-grid { grid-template-columns: 1fr !important; gap: 48px !important; }
          .features-grid { grid-template-columns: 1fr 1fr !important; }
        }
        @media (max-width: 550px) {
          .features-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </section>
  );
}
