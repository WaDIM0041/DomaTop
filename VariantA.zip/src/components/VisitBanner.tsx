"use client";

import { useEffect, useRef, useState } from "react";

export default function VisitBanner() {
  const ref = useRef<HTMLElement>(null);
  const [mousePos, setMousePos] = useState({ x: 50, y: 50 });

  useEffect(() => {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add("visible"); });
    }, { threshold: 0.1 });
    ref.current?.querySelectorAll(".reveal-up").forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  const handleMouseMove = (e: React.MouseEvent<HTMLElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setMousePos({
      x: ((e.clientX - rect.left) / rect.width) * 100,
      y: ((e.clientY - rect.top) / rect.height) * 100,
    });
  };

  return (
    <section
      ref={ref}
      onMouseMove={handleMouseMove}
      style={{ position: "relative", overflow: "hidden" }}
    >
      {/* Parallax BG */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: `url('https://images.pexels.com/photos/36777507/pexels-photo-36777507.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=1400')`,
        backgroundSize: "cover", backgroundPosition: "center",
        backgroundAttachment: "fixed",
      }} />
      {/* Overlay */}
      <div style={{
        position: "absolute", inset: 0,
        background: "linear-gradient(135deg, rgba(8,8,8,0.93) 0%, rgba(8,8,8,0.8) 100%)",
      }} />
      {/* Mouse-follow radial glow */}
      <div style={{
        position: "absolute", inset: 0, pointerEvents: "none",
        background: `radial-gradient(circle 400px at ${mousePos.x}% ${mousePos.y}%, rgba(200,164,90,0.08) 0%, transparent 70%)`,
        transition: "background 0.1s ease",
      }} />

      {/* Top shimmer line */}
      <div className="shimmer-line" style={{ position: "absolute", top: 0, left: 0, right: 0, height: "2px" }} />

      <div style={{
        maxWidth: "1400px", margin: "0 auto",
        padding: "120px 24px", position: "relative", textAlign: "center",
      }}>
        <div className="reveal-up">
          <div className="tag-pill" style={{ marginBottom: "28px" }}>Специальное предложение</div>

          <h2 style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "clamp(30px, 6vw, 72px)",
            fontWeight: 700, color: "#f5f0e8", lineHeight: 1.05, marginBottom: "28px",
          }}>
            Приходите в офис —
            <br />
            <span className="gold-text">покажем 500+ реальных</span>
            <br />
            домов в альбоме
          </h2>

          <p style={{
            color: "rgba(245,240,232,0.6)",
            fontSize: "clamp(16px, 2vw, 20px)",
            lineHeight: 1.75, maxWidth: "620px",
            margin: "0 auto 56px",
          }}>
            Не рендеры — живой фотоальбом каждого построенного объекта.
            Понравился дом — едете смотреть вживую. Так мы работаем 30 лет.
            Первая встреча <strong style={{ color: "#f5f0e8" }}>бесплатна</strong>.
          </p>

          <div style={{ display: "flex", gap: "16px", justifyContent: "center", flexWrap: "wrap", marginBottom: "56px" }}>
            <a href="#contact" className="btn-gold"
              style={{ padding: "20px 52px", fontSize: "14px" }}
              onClick={(e) => { e.preventDefault(); document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" }); }}>
              Записаться на встречу
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M5 12h14M12 5l7 7-7 7"/>
              </svg>
            </a>
            <a href="tel:+79992229292" style={{
              display: "inline-flex", alignItems: "center", gap: "10px",
              padding: "18px 44px",
              border: "1px solid rgba(245,240,232,0.25)",
              color: "#f5f0e8",
              textDecoration: "none", fontSize: "14px", fontWeight: 600,
              letterSpacing: "0.04em", transition: "all 0.3s ease",
            }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLAnchorElement).style.borderColor = "var(--color-accent)"; (e.currentTarget as HTMLAnchorElement).style.color = "var(--color-accent)"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLAnchorElement).style.borderColor = "rgba(245,240,232,0.25)"; (e.currentTarget as HTMLAnchorElement).style.color = "#f5f0e8"; }}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 1.27h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.9a16 16 0 0 0 5.28 5.28l1.99-1.99a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>
              </svg>
              +7 (999) 222-92-92
            </a>
          </div>

          {/* 4 trust badges */}
          <div style={{ display: "flex", justifyContent: "center", gap: "48px", flexWrap: "wrap" }}>
            {[
              { icon: "✓", text: "Бесплатная консультация" },
              { icon: "✓", text: "Реальные объекты вживую" },
              { icon: "✓", text: "Без обязательств" },
              { icon: "✓", text: "Ответ за 30 минут" },
            ].map((item, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                <div style={{
                  width: "22px", height: "22px",
                  border: "1px solid var(--color-accent)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  color: "var(--color-accent)", fontSize: "11px", fontWeight: 700, flexShrink: 0,
                }}>{item.icon}</div>
                <span style={{ fontSize: "14px", color: "rgba(245,240,232,0.6)", fontWeight: 500 }}>{item.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom shimmer line */}
      <div className="shimmer-line" style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: "2px" }} />
    </section>
  );
}
