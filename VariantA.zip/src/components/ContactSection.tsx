"use client";

import { useEffect, useRef, useState } from "react";

export default function ContactSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [formData, setFormData] = useState({ name: "", phone: "", message: "" });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [focusedField, setFocusedField] = useState<string | null>(null);

  useEffect(() => {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add("visible"); });
    }, { threshold: 0.05 });
    sectionRef.current?.querySelectorAll(".reveal-up, .reveal-left, .reveal-right").forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1400));
    setLoading(false);
    setSubmitted(true);
  };

  return (
    <section
      ref={sectionRef}
      id="contact"
      style={{ padding: "130px 0", background: "var(--color-bg)", position: "relative", overflow: "hidden" }}
    >
      <div className="grid-decoration" />

      {/* Glow orbs */}
      <div className="glow-orb" style={{ width: "500px", height: "500px", bottom: "10%", right: "10%", background: "radial-gradient(circle, rgba(200,164,90,0.06) 0%, transparent 70%)" }} />
      <div className="glow-orb" style={{ width: "400px", height: "400px", top: "10%", left: "-5%", background: "radial-gradient(circle, rgba(200,164,90,0.04) 0%, transparent 70%)" }} />

      <div style={{ maxWidth: "1400px", margin: "0 auto", padding: "0 24px", position: "relative" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "80px", alignItems: "start" }} className="contact-grid">

          {/* Left */}
          <div className="reveal-left">
            <div className="tag-pill" style={{ marginBottom: "24px" }}>Свяжитесь с нами</div>
            <h2 style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(30px, 4vw, 56px)",
              fontWeight: 700, color: "#f5f0e8", lineHeight: 1.08, marginBottom: "28px",
            }}>
              Приходите —
              <br /><span className="gold-text">покажем всё</span>
              <br />вживую
            </h2>

            <div className="section-divider" style={{ marginBottom: "32px" }} />

            <p style={{ color: "rgba(245,240,232,0.6)", fontSize: "16px", lineHeight: 1.85, marginBottom: "52px" }}>
              В нашем офисе вы увидите альбом всех реализованных проектов,
              пообщаетесь с техническим специалистом и сделаете первый шаг
              к своему дому. Без обязательств — просто приезжайте.
            </p>

            {/* Contacts */}
            {[
              {
                icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--color-accent)" strokeWidth="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 1.27h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.9a16 16 0 0 0 5.28 5.28l1.99-1.99a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>,
                label: "Позвонить", value: "+7 (999) 222-92-92", href: "tel:+79992229292", big: true,
              },
              {
                icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--color-accent)" strokeWidth="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>,
                label: "Офис", value: "пр. Карла Маркса, 35, офис 9", sub: "Петропавловск-Камчатский",
              },
              {
                icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--color-accent)" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>,
                label: "Режим работы", value: "Пн–Пт: 9:00–18:00", sub: "Сб: 10:00–15:00",
              },
            ].map((c, i) => (
              <a
                key={i}
                href={c.href}
                style={{
                  display: "flex", alignItems: "center", gap: "20px",
                  marginBottom: "20px", textDecoration: "none",
                  padding: "20px 24px",
                  background: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(200,164,90,0.1)",
                  transition: "all 0.3s ease",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLElement).style.background = "rgba(200,164,90,0.05)";
                  (e.currentTarget as HTMLElement).style.borderColor = "rgba(200,164,90,0.25)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.02)";
                  (e.currentTarget as HTMLElement).style.borderColor = "rgba(200,164,90,0.1)";
                }}
              >
                <div style={{
                  width: "48px", height: "48px", flexShrink: 0,
                  border: "1px solid rgba(200,164,90,0.25)",
                  background: "rgba(200,164,90,0.06)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                }}>{c.icon}</div>
                <div>
                  <div style={{ fontSize: "10px", color: "rgba(245,240,232,0.35)", letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: "4px" }}>{c.label}</div>
                  <div style={{ fontSize: c.big ? "22px" : "15px", fontWeight: 700, color: c.big ? "var(--color-accent)" : "#f5f0e8" }}>{c.value}</div>
                  {c.sub && <div style={{ fontSize: "13px", color: "rgba(245,240,232,0.4)", marginTop: "2px" }}>{c.sub}</div>}
                </div>
              </a>
            ))}

            {/* External links */}
            <div style={{ display: "flex", gap: "12px", flexWrap: "wrap", marginTop: "32px" }}>
              {[
                { href: "https://zodkam.ru", label: "zodkam.ru", desc: "Главный сайт" },
                { href: "https://snabzhenie.org", label: "snabzhenie.org", desc: "Стройматериалы" },
              ].map((l) => (
                <a key={l.href} href={l.href} target="_blank" rel="noopener noreferrer" style={{
                  display: "flex", flexDirection: "column", gap: "2px",
                  padding: "14px 20px",
                  background: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(200,164,90,0.12)",
                  textDecoration: "none",
                  transition: "all 0.3s ease",
                }}
                  onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "rgba(200,164,90,0.35)"; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "rgba(200,164,90,0.12)"; }}
                >
                  <span style={{ fontSize: "13px", fontWeight: 700, color: "var(--color-accent)" }}>{l.label}</span>
                  <span style={{ fontSize: "11px", color: "rgba(245,240,232,0.35)" }}>{l.desc}</span>
                </a>
              ))}
            </div>
          </div>

          {/* Right: Form */}
          <div className="reveal-right">
            {submitted ? (
              <div style={{
                padding: "72px 52px", textAlign: "center",
                background: "rgba(200,164,90,0.05)",
                border: "1px solid rgba(200,164,90,0.25)",
                position: "relative",
              }}>
                <div style={{ fontSize: "56px", marginBottom: "24px", filter: "drop-shadow(0 0 20px rgba(200,164,90,0.4))" }}>✅</div>
                <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: "32px", color: "#f5f0e8", marginBottom: "12px" }}>
                  Заявка принята!
                </h3>
                <p style={{ color: "rgba(245,240,232,0.55)", fontSize: "16px", lineHeight: 1.75 }}>
                  Менеджер свяжется с вами в течение 30 минут в рабочее время.
                  Ждите звонка!
                </p>
              </div>
            ) : (
              <div style={{
                padding: "52px 48px",
                background: "rgba(255,255,255,0.015)",
                border: "1px solid rgba(200,164,90,0.12)",
                position: "relative",
                overflow: "hidden",
              }}>
                {/* Top border glow */}
                <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "2px", background: "linear-gradient(90deg, transparent, var(--color-accent), transparent)" }} />
                {/* Corner accents */}
                <div style={{ position: "absolute", top: 0, left: 0, width: "24px", height: "24px", borderTop: "2px solid var(--color-accent)", borderLeft: "2px solid var(--color-accent)" }} />
                <div style={{ position: "absolute", bottom: 0, right: 0, width: "24px", height: "24px", borderBottom: "2px solid var(--color-accent)", borderRight: "2px solid var(--color-accent)" }} />

                <h3 style={{ fontSize: "24px", fontWeight: 700, color: "#f5f0e8", marginBottom: "8px" }}>
                  Получить консультацию
                </h3>
                <p style={{ color: "rgba(245,240,232,0.4)", fontSize: "14px", marginBottom: "40px" }}>
                  Оставьте заявку — перезвоним за 30 минут
                </p>

                <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
                  {[
                    { name: "name", label: "Ваше имя *", placeholder: "Иван Петров", type: "text", required: true },
                    { name: "phone", label: "Телефон *", placeholder: "+7 (___) ___-__-__", type: "tel", required: true },
                  ].map((field) => (
                    <div key={field.name}>
                      <label style={{
                        display: "block", fontSize: "10px",
                        color: focusedField === field.name ? "var(--color-accent)" : "rgba(245,240,232,0.35)",
                        letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: "8px",
                        transition: "color 0.3s ease",
                      }}>{field.label}</label>
                      <input
                        className="form-input"
                        type={field.type}
                        placeholder={field.placeholder}
                        required={field.required}
                        value={formData[field.name as keyof typeof formData]}
                        onChange={(e) => setFormData({ ...formData, [field.name]: e.target.value })}
                        onFocus={() => setFocusedField(field.name)}
                        onBlur={() => setFocusedField(null)}
                      />
                    </div>
                  ))}

                  <div>
                    <label style={{
                      display: "block", fontSize: "10px",
                      color: focusedField === "message" ? "var(--color-accent)" : "rgba(245,240,232,0.35)",
                      letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: "8px",
                      transition: "color 0.3s ease",
                    }}>Расскажите о проекте</label>
                    <textarea
                      className="form-input"
                      rows={4}
                      placeholder="Хочу одноэтажный дом 120 м², участок есть, бюджет обсуждаем..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      onFocus={() => setFocusedField("message")}
                      onBlur={() => setFocusedField(null)}
                      style={{ resize: "vertical" }}
                    />
                  </div>

                  <button type="submit" className="btn-gold" disabled={loading}
                    style={{ width: "100%", justifyContent: "center", marginTop: "8px", padding: "20px" }}>
                    <span style={{ position: "relative", zIndex: 1 }}>
                      {loading ? "Отправляем..." : "Записаться на консультацию"}
                    </span>
                    {!loading && (
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" style={{ position: "relative", zIndex: 1 }}>
                        <path d="M5 12h14M12 5l7 7-7 7"/>
                      </svg>
                    )}
                  </button>

                  <p style={{ fontSize: "11px", color: "rgba(245,240,232,0.25)", textAlign: "center", lineHeight: 1.6 }}>
                    Нажимая кнопку, вы соглашаетесь с обработкой персональных данных.
                    Первая консультация бесплатна.
                  </p>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 900px) { .contact-grid { grid-template-columns: 1fr !important; gap: 48px !important; } }
      `}</style>
    </section>
  );
}
