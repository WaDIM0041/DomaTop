"use client";

const items = [
  "Строительство под ключ",
  "Каркасные дома",
  "Газобетонные дома",
  "Клеёный брус",
  "Фахверк",
  "Индивидуальные проекты",
  "Монолитное строительство",
  "Снабжение материалами",
  "Аренда спецтехники",
  "500+ проектов",
  "Гарантия 5 лет",
  "С 1992 года",
];

export default function MarqueeSection() {
  const doubled = [...items, ...items];

  return (
    <div style={{
      background: "rgba(200,164,90,0.06)",
      borderTop: "1px solid rgba(200,164,90,0.18)",
      borderBottom: "1px solid rgba(200,164,90,0.18)",
      padding: "18px 0",
      overflow: "hidden",
      position: "relative",
    }}>
      {/* Left fade */}
      <div style={{
        position: "absolute", left: 0, top: 0, bottom: 0, width: "120px",
        background: "linear-gradient(to right, var(--color-bg), transparent)",
        zIndex: 2, pointerEvents: "none",
      }} />
      {/* Right fade */}
      <div style={{
        position: "absolute", right: 0, top: 0, bottom: 0, width: "120px",
        background: "linear-gradient(to left, var(--color-bg), transparent)",
        zIndex: 2, pointerEvents: "none",
      }} />

      <div className="marquee-track">
        {doubled.map((item, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: "20px", paddingRight: "20px", whiteSpace: "nowrap" }}>
            <span style={{
              fontSize: "11px", fontWeight: 700,
              letterSpacing: "0.18em", textTransform: "uppercase",
              color: i % 3 === 0 ? "var(--color-accent)" : "rgba(245,240,232,0.45)",
              transition: "color 0.3s ease",
            }}>{item}</span>
            <span style={{
              width: "3px", height: "3px",
              background: "var(--color-accent)",
              borderRadius: "50%", display: "block", flexShrink: 0,
              boxShadow: "0 0 6px rgba(200,164,90,0.8)",
            }} />
          </div>
        ))}
      </div>
    </div>
  );
}
