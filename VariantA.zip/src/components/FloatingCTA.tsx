"use client";

import { useEffect, useState } from "react";

export default function FloatingCTA() {
  const [visible, setVisible] = useState(false);
  const [showTooltip, setShowTooltip] = useState(false);

  useEffect(() => {
    const handle = () => setVisible(window.scrollY > 500);
    window.addEventListener("scroll", handle, { passive: true });
    return () => window.removeEventListener("scroll", handle);
  }, []);

  // Show tooltip after delay
  useEffect(() => {
    if (!visible) return;
    const t = setTimeout(() => setShowTooltip(true), 3000);
    const t2 = setTimeout(() => setShowTooltip(false), 7000);
    return () => { clearTimeout(t); clearTimeout(t2); };
  }, [visible]);

  if (!visible) return null;

  return (
    <div style={{
      position: "fixed", bottom: "28px", right: "28px",
      zIndex: 980, display: "flex", flexDirection: "column",
      gap: "12px", alignItems: "flex-end",
    }}>
      {/* Tooltip */}
      {showTooltip && (
        <div style={{
          background: "rgba(8,8,8,0.95)",
          border: "1px solid rgba(200,164,90,0.3)",
          padding: "12px 16px",
          fontSize: "13px", color: "#f5f0e8",
          whiteSpace: "nowrap",
          animation: "tooltipSlide 0.4s ease",
          position: "relative",
          boxShadow: "0 8px 32px rgba(0,0,0,0.4)",
        }}>
          <strong style={{ color: "var(--color-accent)" }}>Готовы строить?</strong>
          <br />Позвоните прямо сейчас →
          <div style={{
            position: "absolute", bottom: "-6px", right: "24px",
            width: "10px", height: "10px",
            background: "rgba(8,8,8,0.95)",
            border: "1px solid rgba(200,164,90,0.3)",
            borderTop: "none", borderLeft: "none",
            transform: "rotate(45deg)",
          }} />
        </div>
      )}

      {/* WhatsApp */}
      <a
        href="https://wa.me/79992229292"
        target="_blank"
        rel="noopener noreferrer"
        className="float-btn"
        title="Написать в WhatsApp"
        style={{
          width: "50px", height: "50px",
          background: "#25D366",
          display: "flex", alignItems: "center", justifyContent: "center",
          textDecoration: "none",
          boxShadow: "0 8px 24px rgba(37,211,102,0.35)",
          transition: "transform 0.3s ease, box-shadow 0.3s ease",
        }}
        onMouseEnter={(e) => {
          (e.currentTarget as HTMLAnchorElement).style.transform = "scale(1.12)";
          (e.currentTarget as HTMLAnchorElement).style.boxShadow = "0 12px 32px rgba(37,211,102,0.5)";
        }}
        onMouseLeave={(e) => {
          (e.currentTarget as HTMLAnchorElement).style.transform = "scale(1)";
          (e.currentTarget as HTMLAnchorElement).style.boxShadow = "0 8px 24px rgba(37,211,102,0.35)";
        }}
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="white">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z"/>
        </svg>
      </a>

      {/* Phone */}
      <a
        href="tel:+79992229292"
        title="Позвонить"
        style={{
          width: "62px", height: "62px",
          background: "linear-gradient(135deg, #c8a45a, #e8c97a)",
          display: "flex", alignItems: "center", justifyContent: "center",
          textDecoration: "none",
          boxShadow: "0 8px 28px rgba(200,164,90,0.5)",
          position: "relative",
          transition: "transform 0.3s ease, box-shadow 0.3s ease",
          animation: "floatPhone 3s ease-in-out infinite",
        }}
        onMouseEnter={(e) => {
          (e.currentTarget as HTMLAnchorElement).style.transform = "scale(1.1)";
          (e.currentTarget as HTMLAnchorElement).style.boxShadow = "0 12px 40px rgba(200,164,90,0.7)";
        }}
        onMouseLeave={(e) => {
          (e.currentTarget as HTMLAnchorElement).style.transform = "";
          (e.currentTarget as HTMLAnchorElement).style.boxShadow = "0 8px 28px rgba(200,164,90,0.5)";
        }}
      >
        {/* Pulse rings */}
        <div style={{
          position: "absolute", inset: "-8px",
          border: "1px solid rgba(200,164,90,0.4)",
          animation: "phoneRing 2s ease-out infinite",
        }} />
        <div style={{
          position: "absolute", inset: "-16px",
          border: "1px solid rgba(200,164,90,0.2)",
          animation: "phoneRing 2s ease-out infinite 0.7s",
        }} />
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#080808" strokeWidth="2.5">
          <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 1.27h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.9a16 16 0 0 0 5.28 5.28l1.99-1.99a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>
        </svg>
      </a>

      <style>{`
        @keyframes phoneRing {
          0% { transform: scale(1); opacity: 1; }
          100% { transform: scale(1.6); opacity: 0; }
        }
        @keyframes tooltipSlide {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
