"use client";

import { useEffect, useState } from "react";

const navLinks = [
  { label: "О нас", href: "#about" },
  { label: "Проекты", href: "#projects" },
  { label: "Услуги", href: "#services" },
  { label: "Процесс", href: "#process" },
  { label: "Отзывы", href: "#testimonials" },
  { label: "Контакты", href: "#contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("");

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 60);
      // Detect active section
      const sections = navLinks.map((l) => l.href.slice(1));
      for (const id of sections.reverse()) {
        const el = document.getElementById(id);
        if (el && window.scrollY >= el.offsetTop - 120) {
          setActiveSection(id);
          break;
        }
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scroll = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMenuOpen(false);
    document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <>
      <header style={{
        position: "fixed", top: 0, left: 0, right: 0,
        zIndex: 990,
        padding: scrolled ? "10px 0" : "20px 0",
        background: scrolled ? "rgba(8,8,8,0.96)" : "linear-gradient(to bottom, rgba(8,8,8,0.75), transparent)",
        backdropFilter: scrolled ? "blur(20px)" : "none",
        borderBottom: scrolled ? "1px solid rgba(200,164,90,0.1)" : "none",
        transition: "all 0.4s cubic-bezier(0.16,1,0.3,1)",
      }}>
        <div style={{
          maxWidth: "1400px", margin: "0 auto",
          padding: "0 24px",
          display: "flex", alignItems: "center", justifyContent: "space-between",
        }}>
          {/* Logo */}
          <a href="https://zodkam.ru" target="_blank" rel="noopener noreferrer"
            style={{ display: "flex", alignItems: "center", gap: "12px", textDecoration: "none" }}>
            <div className="logo-mark">З</div>
            <div>
              <div style={{
                fontSize: "15px", fontWeight: 900,
                letterSpacing: "0.14em", color: "#f5f0e8",
                textTransform: "uppercase",
              }}>ЗОДЧИЙ</div>
              <div style={{
                fontSize: "8px", color: "var(--color-accent)",
                letterSpacing: "0.25em", textTransform: "uppercase",
                fontWeight: 700, marginTop: "1px",
              }}>с 1992 года</div>
            </div>
          </a>

          {/* Desktop nav */}
          <nav style={{ display: "flex", alignItems: "center", gap: "36px" }} className="nav-desktop">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="nav-link"
                style={{ color: activeSection === link.href.slice(1) ? "var(--color-accent)" : undefined }}
                onClick={(e) => scroll(e, link.href)}
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
            <a href="tel:+79992229292" className="nav-desktop"
              style={{
                display: "flex", alignItems: "center", gap: "8px",
                color: "var(--color-accent)", textDecoration: "none",
                fontSize: "13px", fontWeight: 700, letterSpacing: "0.04em",
              }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 1.27h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.9a16 16 0 0 0 5.28 5.28l1.99-1.99a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>
              </svg>
              +7 (999) 222-92-92
            </a>

            <a href="#contact" className="btn-gold nav-desktop"
              style={{ padding: "10px 22px", fontSize: "11px" }}
              onClick={(e) => scroll(e, "#contact")}>
              Записаться
            </a>

            {/* Burger */}
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="nav-mobile"
              style={{
                background: "none",
                border: "1px solid rgba(200,164,90,0.3)",
                padding: "9px 11px",
                cursor: "none",
                display: "flex", flexDirection: "column", gap: "5px",
              }}
              aria-label="Меню"
            >
              {[0, 1, 2].map((i) => (
                <span key={i} style={{
                  display: "block", width: "22px", height: "1.5px",
                  background: "var(--color-accent)",
                  transition: "all 0.35s ease",
                  transform: menuOpen
                    ? i === 0 ? "rotate(45deg) translateY(6.5px)"
                    : i === 2 ? "rotate(-45deg) translateY(-6.5px)"
                    : "none"
                    : "none",
                  opacity: menuOpen && i === 1 ? 0 : 1,
                }} />
              ))}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      <div className={`mobile-menu ${menuOpen ? "open" : ""}`}>
        {/* Gold accent */}
        <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "2px", background: "linear-gradient(90deg, transparent, var(--color-accent), transparent)" }} />

        {navLinks.map((link, i) => (
          <a
            key={link.href}
            href={link.href}
            onClick={(e) => scroll(e, link.href)}
            style={{
              fontSize: "clamp(24px, 6vw, 36px)", fontWeight: 800,
              color: "#f5f0e8", textDecoration: "none",
              letterSpacing: "0.04em", fontFamily: "'Playfair Display', serif",
              transition: "color 0.3s ease",
              transitionDelay: `${i * 0.06}s`,
            }}
            onMouseEnter={(e) => (e.currentTarget as HTMLAnchorElement).style.color = "var(--color-accent)"}
            onMouseLeave={(e) => (e.currentTarget as HTMLAnchorElement).style.color = "#f5f0e8"}
          >
            {link.label}
          </a>
        ))}

        <a href="tel:+79992229292" style={{
          fontSize: "20px", color: "var(--color-accent)", textDecoration: "none", fontWeight: 700,
          marginTop: "24px",
        }}>
          +7 (999) 222-92-92
        </a>
        <div style={{ fontSize: "13px", color: "rgba(245,240,232,0.3)" }}>
          пр. Карла Маркса, 35, офис 9
        </div>
      </div>

      <style>{`
        @media (max-width: 900px) {
          .nav-desktop { display: none !important; }
          .nav-mobile { display: flex !important; }
        }
        @media (min-width: 901px) {
          .nav-mobile { display: none !important; }
          .nav-desktop { display: flex !important; }
        }
      `}</style>
    </>
  );
}
