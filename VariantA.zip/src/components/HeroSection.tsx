"use client";

import { useEffect, useRef, useState } from "react";

export default function HeroSection() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const heroRef = useRef<HTMLDivElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const [loaded, setLoaded] = useState(false);

  // ── Particle canvas ──────────────────────────────────────────────
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let W = (canvas.width = window.innerWidth);
    let H = (canvas.height = window.innerHeight);
    let mouseX = W / 2, mouseY = H / 2;

    const NUM = 120;
    type Particle = {
      x: number; y: number;
      ox: number; oy: number;
      vx: number; vy: number;
      size: number; alpha: number;
      color: string; speed: number;
    };

    const COLORS = ["#c8a45a", "#e8c97a", "#f0d898", "rgba(200,164,90,0.4)"];

    const particles: Particle[] = Array.from({ length: NUM }, () => ({
      x: Math.random() * W,
      y: Math.random() * H,
      ox: 0, oy: 0,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.3,
      size: Math.random() * 2 + 0.3,
      alpha: Math.random() * 0.6 + 0.1,
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
      speed: Math.random() * 0.5 + 0.1,
    }));

    const onMouseMove = (e: MouseEvent) => { mouseX = e.clientX; mouseY = e.clientY; };
    window.addEventListener("mousemove", onMouseMove);

    const onResize = () => {
      W = canvas.width = window.innerWidth;
      H = canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", onResize);

    let frame: number;
    const draw = () => {
      ctx.clearRect(0, 0, W, H);

      // Draw connection lines between nearby particles
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 100) {
            ctx.beginPath();
            ctx.strokeStyle = `rgba(200,164,90,${0.08 * (1 - dist / 100)})`;
            ctx.lineWidth = 0.5;
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }

      particles.forEach((p) => {
        // Mouse repulsion
        const dx = p.x - mouseX;
        const dy = p.y - mouseY;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 120) {
          const force = (120 - dist) / 120;
          p.vx += (dx / dist) * force * 0.5;
          p.vy += (dy / dist) * force * 0.5;
        }

        // Drift
        p.vx *= 0.98;
        p.vy *= 0.98;
        p.x += p.vx + p.speed * Math.sin(Date.now() * 0.001 + p.ox);
        p.y += p.vy + p.speed * 0.3 * Math.cos(Date.now() * 0.0008 + p.oy);

        // Wrap
        if (p.x < 0) p.x = W;
        if (p.x > W) p.x = 0;
        if (p.y < 0) p.y = H;
        if (p.y > H) p.y = 0;

        // Draw glow
        const grd = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size * 4);
        grd.addColorStop(0, p.color);
        grd.addColorStop(1, "transparent");
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * 4, 0, Math.PI * 2);
        ctx.fillStyle = grd;
        ctx.globalAlpha = p.alpha * 0.3;
        ctx.fill();

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.fill();
        ctx.globalAlpha = 1;
      });

      frame = requestAnimationFrame(draw);
    };
    draw();

    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("resize", onResize);
    };
  }, []);

  // ── Parallax bg ──────────────────────────────────────────────────
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!bgRef.current) return;
      const x = (e.clientX / window.innerWidth - 0.5) * 25;
      const y = (e.clientY / window.innerHeight - 0.5) * 12;
      bgRef.current.style.transform = `translate(${x}px, ${y}px) scale(1.08)`;
    };
    const handleScroll = () => {
      if (!bgRef.current) return;
      bgRef.current.style.transform = `translateY(${window.scrollY * 0.45}px) scale(1.08)`;
    };
    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  // ── Entry animation ──────────────────────────────────────────────
  useEffect(() => {
    const timer = setTimeout(() => setLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  // ── GSAP text split ──────────────────────────────────────────────
  useEffect(() => {
    const gsapLoad = async () => {
      const { gsap } = await import("gsap");
      const { ScrollTrigger } = await import("gsap/ScrollTrigger");
      gsap.registerPlugin(ScrollTrigger);

      // Hero counter ticker
      const counters = document.querySelectorAll("[data-count]");
      counters.forEach((el) => {
        const target = parseInt(el.getAttribute("data-count") || "0");
        gsap.fromTo(
          el,
          { innerText: 0 },
          {
            innerText: target,
            duration: 2.5,
            delay: 1,
            ease: "power2.out",
            snap: { innerText: 1 },
            onUpdate: function () {
              (el as HTMLElement).innerText =
                Math.round(parseFloat((el as HTMLElement).innerText)).toLocaleString("ru") +
                (el.getAttribute("data-suffix") || "");
            },
          }
        );
      });
    };
    gsapLoad();
  }, []);

  return (
    <section
      ref={heroRef}
      id="hero"
      style={{
        position: "relative",
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        overflow: "hidden",
      }}
    >
      {/* BG photo */}
      <div style={{ position: "absolute", inset: "-10%", overflow: "hidden" }}>
        <div
          ref={bgRef}
          style={{
            position: "absolute", inset: 0,
            backgroundImage: `url('https://images.pexels.com/photos/8134821/pexels-photo-8134821.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1080&w=1920')`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            willChange: "transform",
            transition: "transform 0.08s linear",
          }}
        />
        <div style={{
          position: "absolute", inset: 0,
          background: "linear-gradient(135deg, rgba(8,8,8,0.92) 0%, rgba(8,8,8,0.65) 50%, rgba(8,8,8,0.82) 100%)",
        }} />
        {/* Gold radial glow */}
        <div style={{
          position: "absolute", inset: 0,
          background: "radial-gradient(ellipse 80% 60% at 75% 50%, rgba(200,164,90,0.08) 0%, transparent 70%)",
        }} />
      </div>

      {/* Particles canvas */}
      <canvas
        ref={canvasRef}
        style={{ position: "absolute", inset: 0, zIndex: 2, pointerEvents: "none" }}
      />

      {/* Grid */}
      <div className="grid-decoration" style={{ zIndex: 1, opacity: 0.6 }} />

      {/* Horizontal scan line */}
      <div style={{
        position: "absolute", left: 0, right: 0,
        height: "1px", zIndex: 3, pointerEvents: "none",
        background: "linear-gradient(90deg, transparent, rgba(200,164,90,0.4), transparent)",
        animation: "scanLine 8s linear infinite",
        top: "50%",
      }} />

      <style>{`
        @keyframes scanLine {
          0% { top: -2px; opacity: 0; }
          5% { opacity: 1; }
          95% { opacity: 1; }
          100% { top: 100%; opacity: 0; }
        }
        @keyframes heroFadeUp {
          from { opacity: 0; transform: translateY(40px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes heroFadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
      `}</style>

      {/* Content */}
      <div style={{
        maxWidth: "1400px", margin: "0 auto",
        padding: "130px 24px 80px",
        position: "relative", zIndex: 5, width: "100%",
      }}>
        <div style={{ maxWidth: "820px" }}>

          {/* Badge */}
          <div style={{
            display: "inline-flex", alignItems: "center", gap: "12px",
            marginBottom: "36px",
            opacity: loaded ? 1 : 0,
            transform: loaded ? "translateY(0)" : "translateY(20px)",
            transition: "all 0.8s cubic-bezier(0.16,1,0.3,1) 0.1s",
          }}>
            <span className="tag-pill">Строительство домов</span>
            <span className="tag-pill">С 1992 года</span>
          </div>

          {/* Main heading */}
          <h1
            ref={titleRef}
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(44px, 7vw, 96px)",
              fontWeight: 700,
              lineHeight: 1.02,
              color: "#f5f0e8",
              marginBottom: "28px",
              opacity: loaded ? 1 : 0,
              transform: loaded ? "translateY(0)" : "translateY(40px)",
              transition: "all 0.9s cubic-bezier(0.16,1,0.3,1) 0.25s",
            }}
          >
            Строим дома,{" "}
            <br />
            <span className="gold-text" data-text="в которых">
              в которых
            </span>
            <br />
            хочется жить
          </h1>

          {/* Animated line */}
          <div style={{
            height: "2px", width: "120px", marginBottom: "28px",
            background: "linear-gradient(90deg, var(--color-accent), transparent)",
            opacity: loaded ? 1 : 0,
            transform: loaded ? "scaleX(1)" : "scaleX(0)",
            transformOrigin: "left",
            transition: "all 0.8s cubic-bezier(0.16,1,0.3,1) 0.45s",
          }} />

          {/* Subtitle */}
          <p style={{
            fontSize: "clamp(16px, 2vw, 20px)",
            color: "rgba(245, 240, 232, 0.65)",
            lineHeight: 1.75,
            maxWidth: "560px",
            marginBottom: "52px",
            opacity: loaded ? 1 : 0,
            transform: loaded ? "translateY(0)" : "translateY(30px)",
            transition: "all 0.9s cubic-bezier(0.16,1,0.3,1) 0.55s",
          }}>
            Профессиональное строительство одно- и двухэтажных домов под ключ.
            Более <strong style={{ color: "#f5f0e8", fontWeight: 700 }}>500 реализованных проектов</strong>,
            которые вы можете увидеть вживую. Гарантия 5 лет.
          </p>

          {/* CTAs */}
          <div style={{
            display: "flex", gap: "16px", flexWrap: "wrap",
            marginBottom: "72px",
            opacity: loaded ? 1 : 0,
            transform: loaded ? "translateY(0)" : "translateY(30px)",
            transition: "all 0.9s cubic-bezier(0.16,1,0.3,1) 0.7s",
          }}>
            <a href="https://zodkam.ru/typeprojects/" target="_blank" rel="noopener noreferrer"
              className="btn-gold magnetic-btn">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                <polyline points="9 22 9 12 15 12 15 22"/>
              </svg>
              Смотреть проекты
            </a>
            <a href="#contact" className="btn-outline" onClick={(e) => {
              e.preventDefault();
              document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" });
            }}>
              Приехать в офис
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M5 12h14M12 5l7 7-7 7"/>
              </svg>
            </a>
          </div>

          {/* Stats */}
          <div style={{
            display: "flex", gap: "0", flexWrap: "wrap",
            opacity: loaded ? 1 : 0,
            transform: loaded ? "translateY(0)" : "translateY(20px)",
            transition: "all 0.9s cubic-bezier(0.16,1,0.3,1) 0.9s",
          }}>
            {[
              { num: 30, suffix: "+", label: "Лет опыта" },
              { num: 500, suffix: "+", label: "Домов" },
              { num: 5, suffix: " лет", label: "Гарантия" },
              { num: 3000, suffix: "+", label: "м² в год" },
            ].map((stat, i) => (
              <div key={i} className="hero-stat" style={{ paddingRight: "32px", marginRight: "32px", marginBottom: "16px" }}>
                <div style={{
                  fontSize: "clamp(26px, 3.5vw, 38px)",
                  fontWeight: 900,
                  color: "var(--color-accent)",
                  lineHeight: 1,
                  marginBottom: "4px",
                  fontFamily: "'Playfair Display', serif",
                }}>
                  <span data-count={stat.num} data-suffix={stat.suffix}>{stat.num}{stat.suffix}</span>
                </div>
                <div style={{
                  fontSize: "11px", color: "rgba(245,240,232,0.4)",
                  letterSpacing: "0.12em", textTransform: "uppercase",
                }}>
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right accent image */}
        <div style={{
          position: "absolute",
          right: "24px", top: "50%",
          transform: "translateY(-50%)",
          width: "clamp(200px, 28vw, 380px)",
          display: "flex", flexDirection: "column", gap: "16px",
          opacity: loaded ? 1 : 0,
          transition: "opacity 1.2s ease 1.1s",
        }} className="hero-right-panel">
          {/* Mini project card 1 */}
          <div style={{
            position: "relative", overflow: "hidden",
            border: "1px solid rgba(200,164,90,0.2)",
            height: "180px",
          }}>
            <img src="https://images.pexels.com/photos/31737859/pexels-photo-31737859.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=300&w=400"
              alt="Реализованный проект" style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
            <div style={{
              position: "absolute", inset: 0,
              background: "linear-gradient(to top, rgba(8,8,8,0.9), transparent)",
            }} />
            <div style={{ position: "absolute", bottom: "12px", left: "12px" }}>
              <div style={{ fontSize: "10px", color: "var(--color-accent)", fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase" }}>Двухэтажный</div>
              <div style={{ fontSize: "14px", fontWeight: 700, color: "#f5f0e8" }}>Коттедж «Норд»</div>
            </div>
          </div>
          {/* Mini project card 2 */}
          <div style={{
            position: "relative", overflow: "hidden",
            border: "1px solid rgba(200,164,90,0.2)",
            height: "140px",
          }}>
            <img src="https://images.pexels.com/photos/7031604/pexels-photo-7031604.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=200&w=400"
              alt="Реализованный проект" style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
            <div style={{
              position: "absolute", inset: 0,
              background: "linear-gradient(to top, rgba(8,8,8,0.9), transparent)",
            }} />
            <div style={{
              position: "absolute",
              top: "12px", right: "12px",
              background: "var(--color-accent)",
              color: "#080808",
              padding: "4px 10px",
              fontSize: "10px",
              fontWeight: 700,
              letterSpacing: "0.1em",
              textTransform: "uppercase",
            }}>
              НОВИНКА
            </div>
            <div style={{ position: "absolute", bottom: "12px", left: "12px" }}>
              <div style={{ fontSize: "14px", fontWeight: 700, color: "#f5f0e8" }}>Фахверк «Брукс»</div>
            </div>
          </div>
          {/* Rating block */}
          <div style={{
            padding: "16px 20px",
            background: "rgba(200,164,90,0.08)",
            border: "1px solid rgba(200,164,90,0.2)",
            display: "flex", alignItems: "center", gap: "16px",
          }}>
            <div>
              <div style={{ fontSize: "28px", fontWeight: 900, color: "var(--color-accent)", fontFamily: "'Playfair Display', serif", lineHeight: 1 }}>4.9</div>
              <div style={{ display: "flex", gap: "2px", marginTop: "4px" }}>
                {"★★★★★".split("").map((s, i) => <span key={i} style={{ color: "var(--color-accent)", fontSize: "12px" }}>{s}</span>)}
              </div>
            </div>
            <div>
              <div style={{ fontSize: "12px", fontWeight: 600, color: "#f5f0e8" }}>Рейтинг</div>
              <div style={{ fontSize: "11px", color: "rgba(245,240,232,0.4)" }}>500+ довольных клиентов</div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll hint */}
      <div style={{
        position: "absolute", bottom: "36px", left: "50%",
        transform: "translateX(-50%)",
        zIndex: 5, display: "flex", flexDirection: "column", alignItems: "center", gap: "10px",
        opacity: loaded ? 0.7 : 0,
        transition: "opacity 1s ease 1.5s",
      }}>
        <div style={{ fontSize: "9px", color: "rgba(245,240,232,0.4)", letterSpacing: "0.25em", textTransform: "uppercase" }}>
          Scroll
        </div>
        <div style={{
          width: "20px", height: "32px",
          border: "1px solid rgba(200,164,90,0.3)",
          borderRadius: "10px",
          position: "relative",
          display: "flex", justifyContent: "center", paddingTop: "5px",
        }}>
          <div style={{
            width: "3px", height: "8px",
            background: "var(--color-accent)",
            borderRadius: "2px",
            animation: "scrollBounce 1.8s ease infinite",
          }} />
        </div>
      </div>

      <style>{`
        @media (max-width: 1100px) { .hero-right-panel { display: none !important; } }
      `}</style>
    </section>
  );
}
