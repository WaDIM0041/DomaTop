"use client";

import { useEffect, useRef, useState } from "react";

const testimonials = [
  {
    name: "Александр В.",
    location: "Петропавловск-Камчатский",
    date: "2024",
    project: "Двухэтажный дом 143 м², «Аврора»",
    rating: 5,
    text: "Приехали в офис, посмотрели реализованные дома своими глазами — это решило все сомнения. Проект адаптировали под наш участок за неделю. Строили чётко по договору. Теперь живём в доме мечты. Соседи уже спрашивают контакт!",
    avatar: "А",
    color: "#c8a45a",
  },
  {
    name: "Марина и Олег К.",
    location: "Камчатский край",
    date: "2024",
    project: "Одноэтажный дом 128 м², «Норд»",
    rating: 5,
    text: "Впечатлила база материалов — закупали через snabzhenie.org и сэкономили значительно. Менеджер была на связи 24/7. Отчёты с объекта приходили регулярно. Сдали на 2 недели раньше срока. Рекомендуем без раздумий!",
    avatar: "М",
    color: "#d4b068",
  },
  {
    name: "Дмитрий Н.",
    location: "Вилючинск",
    date: "2023",
    project: "Коттедж по инд. проекту, 180 м²",
    rating: 5,
    text: "Хотел дом, которого нет ни у кого. Технический специалист разработал проект с нуля под мои эскизы. Материалы собственного производства — качество видно сразу. Гарантия 5 лет — это реальная уверенность, а не слова.",
    avatar: "Д",
    color: "#e0be82",
  },
  {
    name: "Семья Петровых",
    location: "Елизово",
    date: "2023",
    project: "Каркасный дом 109 м², «Олимп»",
    rating: 5,
    text: "Работали терпеливо, объяснили все тонкости, помогли оформить ипотеку. Дом тёплый даже в камчатские морозы. Настоящие профессионалы с 30-летним опытом — это чувствуется в каждой детали.",
    avatar: "П",
    color: "#c8a45a",
  },
];

export default function TestimonialsSection() {
  const [active, setActive] = useState(0);
  const sectionRef = useRef<HTMLElement>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const startTimer = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = setInterval(() => {
      setActive((p) => (p + 1) % testimonials.length);
    }, 5500);
  };

  useEffect(() => {
    startTimer();
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, []);

  useEffect(() => {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add("visible"); });
    }, { threshold: 0.05 });
    sectionRef.current?.querySelectorAll(".reveal-up, .reveal-left, .reveal-right").forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  const t = testimonials[active];

  return (
    <section
      ref={sectionRef}
      id="testimonials"
      style={{ padding: "130px 0", background: "var(--color-bg-2)", position: "relative", overflow: "hidden" }}
    >
      <div className="grid-decoration" />

      {/* Huge quote mark */}
      <div style={{
        position: "absolute", top: "10%", right: "-2%",
        fontFamily: "serif", fontSize: "clamp(200px, 30vw, 400px)",
        color: "rgba(200,164,90,0.03)",
        lineHeight: 1, userSelect: "none", pointerEvents: "none",
      }}>&ldquo;</div>

      <div style={{ maxWidth: "1400px", margin: "0 auto", padding: "0 24px", position: "relative" }}>

        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: "72px" }} className="reveal-up">
          <div className="tag-pill" style={{ marginBottom: "16px" }}>Отзывы клиентов</div>
          <h2 style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "clamp(30px, 4.5vw, 58px)",
            fontWeight: 700, color: "#f5f0e8", lineHeight: 1.08,
          }}>
            Что говорят люди,
            <br /><span className="gold-text">которые уже живут</span>
          </h2>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "60px", alignItems: "start" }} className="testimonials-grid">

          {/* Main testimonial */}
          <div className="reveal-left">
            <div style={{
              background: "rgba(255,255,255,0.02)",
              border: "1px solid rgba(200,164,90,0.15)",
              padding: "48px",
              position: "relative",
              overflow: "hidden",
              minHeight: "340px",
            }}>
              {/* Top gold bar */}
              <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "2px", background: `linear-gradient(90deg, ${t.color}, transparent)` }} />

              {/* Stars */}
              <div style={{ display: "flex", gap: "4px", marginBottom: "28px" }}>
                {Array.from({ length: 5 }).map((_, i) => (
                  <span key={i} style={{ color: "var(--color-accent)", fontSize: "18px", filter: "drop-shadow(0 0 4px rgba(200,164,90,0.6))" }}>★</span>
                ))}
              </div>

              <p style={{
                fontSize: "17px", color: "rgba(245,240,232,0.85)",
                lineHeight: 1.85, marginBottom: "36px", fontStyle: "italic",
              }}>
                &ldquo;{t.text}&rdquo;
              </p>

              <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
                <div style={{
                  width: "52px", height: "52px", flexShrink: 0,
                  background: `linear-gradient(135deg, ${t.color}, var(--color-accent-light))`,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: "20px", fontWeight: 800, color: "#080808",
                  clip: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)",
                }}>{t.avatar}</div>
                <div>
                  <div style={{ fontSize: "15px", fontWeight: 700, color: "#f5f0e8", marginBottom: "3px" }}>{t.name}</div>
                  <div style={{ fontSize: "12px", color: "rgba(245,240,232,0.35)" }}>{t.location}</div>
                  <div style={{ fontSize: "12px", color: "rgba(200,164,90,0.6)", marginTop: "2px" }}>{t.project} · {t.date}</div>
                </div>
              </div>

              {/* Decorative corner */}
              <div style={{ position: "absolute", bottom: 0, right: 0, width: "50px", height: "50px", background: "linear-gradient(135deg, transparent 50%, rgba(200,164,90,0.05) 50%)" }} />
            </div>

            {/* Navigation */}
            <div style={{ display: "flex", gap: "8px", marginTop: "20px", alignItems: "center" }}>
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  onClick={() => { setActive(i); startTimer(); }}
                  style={{
                    height: "3px",
                    width: i === active ? "36px" : "12px",
                    background: i === active ? "var(--color-accent)" : "rgba(200,164,90,0.2)",
                    border: "none", cursor: "none", padding: 0,
                    transition: "all 0.4s ease",
                    boxShadow: i === active ? "0 0 8px rgba(200,164,90,0.6)" : "none",
                  }}
                />
              ))}
              <div style={{ marginLeft: "auto", fontSize: "12px", color: "rgba(245,240,232,0.3)" }}>
                {active + 1} / {testimonials.length}
              </div>
            </div>
          </div>

          {/* Right side: review cards list */}
          <div className="reveal-right" style={{ display: "flex", flexDirection: "column", gap: "3px" }}>
            {testimonials.map((t2, i) => (
              <div
                key={i}
                onClick={() => { setActive(i); startTimer(); }}
                style={{
                  padding: "20px 24px",
                  background: i === active ? "rgba(200,164,90,0.07)" : "rgba(255,255,255,0.015)",
                  border: `1px solid ${i === active ? "rgba(200,164,90,0.3)" : "rgba(255,255,255,0.04)"}`,
                  cursor: "none",
                  transition: "all 0.35s ease",
                  position: "relative",
                  overflow: "hidden",
                }}
              >
                {i === active && <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: "2px", background: "var(--color-accent)", boxShadow: "0 0 8px rgba(200,164,90,0.6)" }} />}

                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                  <span style={{ fontSize: "14px", fontWeight: 700, color: i === active ? "#f5f0e8" : "rgba(245,240,232,0.5)", transition: "color 0.3s" }}>{t2.name}</span>
                  <div style={{ display: "flex", gap: "2px" }}>
                    {Array.from({ length: 5 }).map((_, j) => <span key={j} style={{ color: "var(--color-accent)", fontSize: "11px" }}>★</span>)}
                  </div>
                </div>
                <div style={{ fontSize: "12px", color: "rgba(245,240,232,0.3)" }}>{t2.project}</div>
              </div>
            ))}

            {/* Rating summary */}
            <div style={{
              marginTop: "8px", padding: "28px 24px",
              background: "rgba(200,164,90,0.04)",
              border: "1px solid rgba(200,164,90,0.12)",
              display: "flex", gap: "24px", alignItems: "center",
            }}>
              <div style={{ textAlign: "center" }}>
                <div style={{
                  fontSize: "48px", fontWeight: 900, color: "var(--color-accent)",
                  fontFamily: "'Playfair Display', serif", lineHeight: 1,
                  filter: "drop-shadow(0 0 12px rgba(200,164,90,0.4))",
                }}>4.9</div>
                <div style={{ display: "flex", gap: "2px", justifyContent: "center", marginTop: "6px" }}>
                  {"★★★★★".split("").map((s, i) => <span key={i} style={{ color: "var(--color-accent)", fontSize: "14px" }}>{s}</span>)}
                </div>
              </div>
              <div>
                <div style={{ fontSize: "15px", fontWeight: 700, color: "#f5f0e8", marginBottom: "4px" }}>Средний рейтинг</div>
                <div style={{ fontSize: "13px", color: "rgba(245,240,232,0.4)", lineHeight: 1.5 }}>
                  По отзывам 500+
                  <br />клиентов компании
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 900px) { .testimonials-grid { grid-template-columns: 1fr !important; } }
      `}</style>
    </section>
  );
}
