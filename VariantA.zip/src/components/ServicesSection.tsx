"use client";

import { useEffect, useRef } from "react";

const services = [
  { num: "01", title: "Строительство домов под ключ", desc: "Полный цикл от проекта до вручения ключей. Каркасные, монолитные, газобетонные, из клеёного бруса и фахверка. Точно в срок.", link: "https://zodkam.ru", cta: "На сайт компании", highlight: true },
  { num: "02", title: "Индивидуальное проектирование", desc: "Технический специалист разработает проект с нуля или модернизирует готовый. Приходите с идеей — уйдёте с планом.", link: "https://zodkam.ru/typeprojects/", cta: "Смотреть проекты" },
  { num: "03", title: "База готовых проектов", desc: "100+ типовых домов, бань, беседок. Все объекты реальны и открыты для посещения. Приезжайте — увидите своими глазами.", link: "https://zodkam.ru/works/", cta: "Наши работы" },
  { num: "04", title: "Поставка стройматериалов", desc: "Собственная база снабжения. Knauf, Rockwool, Grand Line, пиломатериалы, аренда опалубки и спецтехники. Оптом и в розницу.", link: "https://snabzhenie.org", cta: "snabzhenie.org", badge: true },
  { num: "05", title: "Земельные участки", desc: "Собственные участки для строительства в удобных локациях. Подберём оптимальный под ваш проект и бюджет.", link: "https://zodkam.ru", cta: "Подробнее" },
  { num: "06", title: "Ипотека и господдержка", desc: "Помогаем оформить ипотеку и воспользоваться государственными программами субсидирования строительства.", link: "#contact", cta: "Проконсультироваться", internal: true },
];

export default function ServicesSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add("visible"); });
    }, { threshold: 0.04 });
    sectionRef.current?.querySelectorAll(".reveal-up, .reveal-left").forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="services"
      style={{ padding: "130px 0", background: "var(--color-bg-2)", position: "relative", overflow: "hidden" }}
    >
      <div className="grid-decoration" />
      <div className="glow-orb" style={{ width: "700px", height: "700px", top: "20%", right: "-20%", background: "radial-gradient(circle, rgba(200,164,90,0.04) 0%, transparent 70%)" }} />

      <div style={{ maxWidth: "1400px", margin: "0 auto", padding: "0 24px" }}>

        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: "72px", flexWrap: "wrap", gap: "32px" }}>
          <div className="reveal-left">
            <div className="tag-pill" style={{ marginBottom: "16px" }}>Что мы делаем</div>
            <h2 style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(30px, 4.5vw, 58px)",
              fontWeight: 700, color: "#f5f0e8", lineHeight: 1.08,
            }}>
              Всё для вашего
              <br /><span className="gold-text">будущего дома</span>
            </h2>
          </div>
          <div className="reveal-up" style={{ maxWidth: "340px" }}>
            <p style={{ color: "rgba(245,240,232,0.5)", fontSize: "15px", lineHeight: 1.75 }}>
              Единая экосистема: проектирование, строительство,
              материалы и сервис. Один звонок — мы берём на себя всё.
            </p>
          </div>
        </div>

        {/* Services rows */}
        <div style={{ display: "flex", flexDirection: "column", gap: "2px" }}>
          {services.map((s, i) => (
            <div
              key={i}
              className="service-row reveal-up"
              style={{
                transitionDelay: `${i * 0.06}s`,
                padding: "32px 36px",
                display: "grid",
                gridTemplateColumns: "70px 1fr auto",
                gap: "28px",
                alignItems: "center",
                background: s.highlight ? "rgba(200,164,90,0.06)" : "rgba(255,255,255,0.015)",
                border: `1px solid ${s.highlight ? "rgba(200,164,90,0.25)" : "rgba(255,255,255,0.04)"}`,
                position: "relative",
                overflow: "hidden",
              }}
              onClick={() => {
                if (s.internal) document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" });
                else window.open(s.link, "_blank", "noopener");
              }}
            >
              {/* Left glow on highlight */}
              {s.highlight && (
                <div style={{
                  position: "absolute", left: 0, top: 0, bottom: 0,
                  width: "3px",
                  background: "linear-gradient(to bottom, transparent, var(--color-accent), transparent)",
                }} />
              )}

              {/* Number */}
              <div style={{
                fontSize: "48px", fontWeight: 900, lineHeight: 1,
                fontFamily: "'Playfair Display', serif",
                color: s.highlight ? "var(--color-accent)" : "rgba(200,164,90,0.18)",
                transition: "color 0.3s ease",
              }}>{s.num}</div>

              {/* Content */}
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "8px" }}>
                  <h3 style={{ fontSize: "17px", fontWeight: 700, color: "#f5f0e8", letterSpacing: "0.01em" }}>
                    {s.title}
                  </h3>
                  {s.badge && (
                    <span style={{
                      padding: "3px 8px",
                      background: "rgba(200,164,90,0.15)",
                      border: "1px solid rgba(200,164,90,0.3)",
                      color: "var(--color-accent)",
                      fontSize: "9px", fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase",
                    }}>Партнёр</span>
                  )}
                </div>
                <p style={{ fontSize: "14px", color: "rgba(245,240,232,0.45)", lineHeight: 1.7, maxWidth: "560px" }}>
                  {s.desc}
                </p>
              </div>

              {/* Arrow CTA */}
              <div className="service-arrow" style={{
                display: "flex", alignItems: "center", gap: "8px",
                color: "rgba(200,164,90,0.35)",
                fontSize: "12px", fontWeight: 700,
                letterSpacing: "0.1em", textTransform: "uppercase",
                transition: "all 0.3s ease", flexShrink: 0, whiteSpace: "nowrap",
              }}>
                {s.cta}
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <path d="M5 12h14M12 5l7 7-7 7"/>
                </svg>
              </div>
            </div>
          ))}
        </div>

        {/* Snabzhenie feature block */}
        <div style={{ marginTop: "60px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "3px" }} className="snab-grid reveal-up">
          <div style={{
            padding: "56px 52px",
            background: "rgba(200,164,90,0.04)",
            border: "1px solid rgba(200,164,90,0.15)",
            position: "relative", overflow: "hidden",
          }}>
            {/* Animated border shimmer */}
            <div className="shimmer-line" style={{ position: "absolute", top: 0, left: 0, right: 0, height: "1px" }} />

            <div className="tag-pill" style={{ marginBottom: "24px" }}>Снабжение материалами</div>
            <h3 style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(22px, 3vw, 36px)",
              color: "#f5f0e8", marginBottom: "16px", lineHeight: 1.2,
            }}>
              Материалы напрямую
              <br />от <span className="gold-text">производителей</span>
            </h3>
            <p style={{ color: "rgba(245,240,232,0.5)", fontSize: "15px", lineHeight: 1.75, marginBottom: "36px" }}>
              Knauf, Rockwool, Grand Line, пиломатериалы, инструмент.
              Аренда опалубки и лесов. 3900+ товаров в наличии.
              Доставка по городу бесплатно.
            </p>

            <div style={{ display: "flex", gap: "16px", flexWrap: "wrap", marginBottom: "36px" }}>
              {["Knauf Nord 33", "Grand Line", "Rockwool", "Пиломатериалы", "Аренда спецтехники"].map((m) => (
                <span key={m} style={{
                  padding: "6px 12px",
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(200,164,90,0.12)",
                  color: "rgba(245,240,232,0.6)",
                  fontSize: "12px", fontWeight: 500,
                }}>{m}</span>
              ))}
            </div>

            <a href="https://snabzhenie.org" target="_blank" rel="noopener noreferrer" className="btn-gold">
              Перейти в магазин snabzhenie.org
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M5 12h14M12 5l7 7-7 7"/>
              </svg>
            </a>
          </div>

          {/* Right image */}
          <div style={{ position: "relative", overflow: "hidden", minHeight: "320px" }}>
            <img
              src="https://images.pexels.com/photos/7937319/pexels-photo-7937319.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=700"
              alt="Строительные материалы"
              style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", transition: "transform 0.6s ease" }}
              onMouseEnter={(e) => (e.currentTarget as HTMLImageElement).style.transform = "scale(1.05)"}
              onMouseLeave={(e) => (e.currentTarget as HTMLImageElement).style.transform = "scale(1)"}
            />
            <div style={{
              position: "absolute", inset: 0,
              background: "linear-gradient(135deg, rgba(8,8,8,0.6), rgba(200,164,90,0.08))",
            }} />
            <div style={{ position: "absolute", bottom: "32px", left: "32px" }}>
              <div style={{ fontSize: "44px", fontWeight: 900, color: "var(--color-accent)", fontFamily: "'Playfair Display', serif", lineHeight: 1 }}>3 900+</div>
              <div style={{ fontSize: "15px", color: "#f5f0e8", fontWeight: 600 }}>товаров в наличии</div>
              <div style={{ fontSize: "12px", color: "rgba(245,240,232,0.4)", marginTop: "4px" }}>snabzhenie.org</div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 768px) {
          .service-row { grid-template-columns: 50px 1fr !important; padding: 20px !important; }
          .service-row > div:last-child { display: none; }
          .snab-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </section>
  );
}
