"use client";

import { useEffect, useRef, useState } from "react";

const stats = [
  { value: 30, suffix: "+", label: "Лет на рынке", desc: "Работаем с 1992 года", icon: "🏛️" },
  { value: 500, suffix: "+", label: "Домов построено", desc: "Реализованных проектов", icon: "🏠" },
  { value: 5, suffix: " лет", label: "Гарантия", desc: "На все виды работ", icon: "🛡️" },
  { value: 3000, suffix: "+", label: "м² в год", desc: "Жилой площади", icon: "📐" },
];

function AnimCounter({ value, suffix }: { value: number; suffix: string }) {
  const [count, setCount] = useState(0);
  const [started, setStarted] = useState(false);
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => {
      if (e.isIntersecting && !started) {
        setStarted(true);
        let start = 0;
        const duration = 2200;
        const step = (value / duration) * 16;
        const timer = setInterval(() => {
          start += step;
          if (start >= value) { setCount(value); clearInterval(timer); }
          else setCount(Math.floor(start));
        }, 16);
      }
    }, { threshold: 0.5 });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [value, started]);

  return <span ref={ref}>{count.toLocaleString("ru")}{suffix}</span>;
}

export default function StatsSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add("visible"); });
    }, { threshold: 0.05 });
    sectionRef.current?.querySelectorAll(".reveal-up").forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      style={{ padding: "0", position: "relative", background: "var(--color-bg)", overflow: "hidden" }}
    >
      {/* Full-bleed parallax bg */}
      <div style={{
        position: "relative",
        padding: "100px 0",
        background: "var(--color-bg-2)",
        borderTop: "1px solid rgba(200,164,90,0.1)",
        borderBottom: "1px solid rgba(200,164,90,0.1)",
        overflow: "hidden",
      }}>
        {/* Animated background */}
        <div style={{
          position: "absolute", inset: 0,
          backgroundImage: `url('https://images.pexels.com/photos/8961296/pexels-photo-8961296.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=1400')`,
          backgroundSize: "cover", backgroundPosition: "center",
          opacity: 0.06,
        }} />
        {/* Shimmer overlay */}
        <div style={{
          position: "absolute", inset: 0,
          background: "linear-gradient(to right, var(--color-bg-2) 0%, transparent 20%, transparent 80%, var(--color-bg-2) 100%)",
        }} />
        {/* Moving gold stripe */}
        <div className="shimmer-line" style={{
          position: "absolute", top: 0, left: 0, right: 0, height: "1px",
        }} />
        <div className="shimmer-line" style={{
          position: "absolute", bottom: 0, left: 0, right: 0, height: "1px",
        }} />

        <div style={{ maxWidth: "1400px", margin: "0 auto", padding: "0 24px", position: "relative" }}>
          <div style={{
            display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "1px",
            background: "rgba(200,164,90,0.06)",
          }} className="stats-grid">
            {stats.map((s, i) => (
              <div
                key={i}
                className="reveal-up"
                style={{
                  transitionDelay: `${i * 0.1}s`,
                  padding: "52px 36px",
                  background: "rgba(8,8,8,0.6)",
                  backdropFilter: "blur(20px)",
                  textAlign: "center",
                  position: "relative",
                  overflow: "hidden",
                  border: "1px solid rgba(200,164,90,0.06)",
                  transition: "all 0.4s ease",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLDivElement).style.background = "rgba(200,164,90,0.05)";
                  (e.currentTarget as HTMLDivElement).style.borderColor = "rgba(200,164,90,0.2)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLDivElement).style.background = "rgba(8,8,8,0.6)";
                  (e.currentTarget as HTMLDivElement).style.borderColor = "rgba(200,164,90,0.06)";
                }}
              >
                {/* Radial glow */}
                <div style={{
                  position: "absolute", inset: 0,
                  background: "radial-gradient(circle at 50% 0%, rgba(200,164,90,0.08) 0%, transparent 70%)",
                  pointerEvents: "none",
                }} />

                <div style={{ fontSize: "32px", marginBottom: "16px" }}>{s.icon}</div>

                <div style={{
                  fontSize: "clamp(40px, 5vw, 64px)",
                  fontWeight: 900,
                  color: "var(--color-accent)",
                  fontFamily: "'Playfair Display', serif",
                  lineHeight: 1, marginBottom: "12px",
                  letterSpacing: "-0.02em",
                }}>
                  <AnimCounter value={s.value} suffix={s.suffix} />
                </div>

                <div style={{ fontSize: "15px", fontWeight: 700, color: "#f5f0e8", marginBottom: "6px" }}>
                  {s.label}
                </div>
                <div style={{ fontSize: "12px", color: "rgba(245,240,232,0.35)", letterSpacing: "0.06em" }}>
                  {s.desc}
                </div>

                {/* Corner decoration */}
                <div style={{
                  position: "absolute", bottom: 0, right: 0,
                  width: "50px", height: "50px",
                  background: "linear-gradient(135deg, transparent 50%, rgba(200,164,90,0.06) 50%)",
                }} />
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 768px) { .stats-grid { grid-template-columns: 1fr 1fr !important; } }
        @media (max-width: 400px) { .stats-grid { grid-template-columns: 1fr !important; } }
      `}</style>
    </section>
  );
}
