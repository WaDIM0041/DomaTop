"use client";

import { useEffect, useRef, useState } from "react";

const projects = [
  {
    name: "Аврора 12",
    type: "Двухэтажный",
    area: "143 м²",
    tag: "Популярный",
    rooms: "3 комнаты · 3 санузла",
    image: "https://images.pexels.com/photos/8134821/pexels-photo-8134821.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=600",
    size: "big",
  },
  {
    name: "Норд",
    type: "Одноэтажный",
    area: "128 м²",
    tag: "Скандинавский",
    rooms: "Скандинавский стиль",
    image: "https://images.pexels.com/photos/8082328/pexels-photo-8082328.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    size: "small",
  },
  {
    name: "Брукс 162",
    type: "Одноэтажный",
    area: "162 м²",
    tag: "Премиум",
    rooms: "Фахверк · Панорамные окна",
    image: "https://images.pexels.com/photos/7598375/pexels-photo-7598375.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    size: "small",
  },
  {
    name: "Грань",
    type: "Двухэтажный",
    area: "127 м²",
    tag: "Хит продаж",
    rooms: "Barnhouse · Лофт",
    image: "https://images.pexels.com/photos/31737859/pexels-photo-31737859.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    size: "small",
  },
  {
    name: "Олимп",
    type: "Двухэтажный",
    area: "109 м²",
    tag: "Для семьи",
    rooms: "4 спальни · 2 санузла",
    image: "https://images.pexels.com/photos/7031412/pexels-photo-7031412.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    size: "small",
  },
  {
    name: "Орион",
    type: "Одноэтажный",
    area: "170 м²",
    tag: "Просторный",
    rooms: "Панорамные окна · 1 этаж",
    image: "https://images.pexels.com/photos/8089172/pexels-photo-8089172.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=700",
    size: "small",
  },
];

export default function ProjectsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const [cursorPos, setCursorPos] = useState({ x: 0, y: 0 });
  const [showLabel, setShowLabel] = useState(false);

  useEffect(() => {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add("visible"); });
    }, { threshold: 0.05 });
    sectionRef.current?.querySelectorAll(".reveal-up, .reveal-left").forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  const handleMouseMove = (e: React.MouseEvent) => {
    setCursorPos({ x: e.clientX, y: e.clientY });
  };

  return (
    <section
      ref={sectionRef}
      id="projects"
      onMouseMove={handleMouseMove}
      style={{ padding: "130px 0", background: "var(--color-bg-2)", position: "relative", overflow: "hidden" }}
    >
      <div className="grid-decoration" />

      {/* Custom cursor label */}
      {showLabel && hoveredIdx !== null && (
        <div style={{
          position: "fixed",
          left: cursorPos.x + 20, top: cursorPos.y + 20,
          background: "var(--color-accent)",
          color: "#080808",
          padding: "8px 16px",
          fontSize: "11px", fontWeight: 800,
          letterSpacing: "0.12em", textTransform: "uppercase",
          pointerEvents: "none",
          zIndex: 9997,
          whiteSpace: "nowrap",
        }}>
          Смотреть проект →
        </div>
      )}

      <div style={{ maxWidth: "1400px", margin: "0 auto", padding: "0 24px" }}>

        {/* Header */}
        <div style={{
          display: "flex", alignItems: "flex-end", justifyContent: "space-between",
          marginBottom: "60px", flexWrap: "wrap", gap: "24px",
        }}>
          <div className="reveal-left">
            <div className="tag-pill" style={{ marginBottom: "16px" }}>Каталог проектов</div>
            <h2 style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(30px, 4.5vw, 58px)",
              fontWeight: 700, color: "#f5f0e8", lineHeight: 1.08,
            }}>
              Проекты, которые
              <br />
              <span className="gold-text">уже стали домами</span>
            </h2>
          </div>
          <div className="reveal-up" style={{ maxWidth: "320px" }}>
            <p style={{ color: "rgba(245,240,232,0.5)", fontSize: "15px", lineHeight: 1.75, marginBottom: "20px" }}>
              Каждый — реальный объект. Выбираете понравившийся — едете смотреть вживую.
            </p>
            <a href="https://zodkam.ru/typeprojects/" target="_blank" rel="noopener noreferrer" className="btn-outline">
              Все 100+ проектов
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M5 12h14M12 5l7 7-7 7"/>
              </svg>
            </a>
          </div>
        </div>

        {/* Mosaic grid */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(12, 1fr)",
          gridTemplateRows: "auto",
          gap: "3px",
        }} className="mosaic-grid reveal-up">

          {/* Big card */}
          <div
            className="project-card"
            style={{ gridColumn: "span 5", gridRow: "span 2", position: "relative", minHeight: "500px", cursor: "none" }}
            onMouseEnter={() => { setHoveredIdx(0); setShowLabel(true); }}
            onMouseLeave={() => { setHoveredIdx(null); setShowLabel(false); }}
            onClick={() => window.open("https://zodkam.ru/typeprojects/", "_blank")}
          >
            <img src={projects[0].image} alt={projects[0].name} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />
            <div className="project-card-overlay" />
            <div style={{ position: "absolute", top: "16px", left: "16px" }}>
              <span className="tag-pill" style={{ fontSize: "9px" }}>{projects[0].tag}</span>
            </div>
            <ProjectInfo p={projects[0]} />
          </div>

          {/* Row 1 — 2 cards */}
          {projects.slice(1, 3).map((p, i) => (
            <div
              key={i}
              className="project-card"
              style={{ gridColumn: "span 3", position: "relative", minHeight: "240px", cursor: "none" }}
              onMouseEnter={() => { setHoveredIdx(i + 1); setShowLabel(true); }}
              onMouseLeave={() => { setHoveredIdx(null); setShowLabel(false); }}
              onClick={() => window.open("https://zodkam.ru/typeprojects/", "_blank")}
            >
              <img src={p.image} alt={p.name} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />
              <div className="project-card-overlay" />
              <div style={{ position: "absolute", top: "10px", right: "10px" }}>
                <span className="tag-pill" style={{ fontSize: "9px" }}>{p.tag}</span>
              </div>
              <ProjectInfo p={p} small />
            </div>
          ))}

          {/* Row 2 — 3 more cards */}
          {projects.slice(3, 6).map((p, i) => (
            <div
              key={i}
              className="project-card"
              style={{ gridColumn: "span 4", position: "relative", minHeight: "240px", cursor: "none" }}
              onMouseEnter={() => { setHoveredIdx(i + 3); setShowLabel(true); }}
              onMouseLeave={() => { setHoveredIdx(null); setShowLabel(false); }}
              onClick={() => window.open("https://zodkam.ru/typeprojects/", "_blank")}
            >
              <img src={p.image} alt={p.name} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />
              <div className="project-card-overlay" />
              <div style={{ position: "absolute", top: "10px", left: "10px" }}>
                <span className="tag-pill" style={{ fontSize: "9px" }}>{p.tag}</span>
              </div>
              <ProjectInfo p={p} small />
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="reveal-up" style={{
          marginTop: "64px",
          padding: "64px",
          border: "1px solid rgba(200,164,90,0.12)",
          background: "rgba(200,164,90,0.02)",
          position: "relative",
          overflow: "hidden",
          textAlign: "center",
        }}>
          {/* Animated corner decorations */}
          <div style={{ position: "absolute", top: 0, left: 0, width: "40px", height: "40px", borderTop: "2px solid var(--color-accent)", borderLeft: "2px solid var(--color-accent)" }} />
          <div style={{ position: "absolute", top: 0, right: 0, width: "40px", height: "40px", borderTop: "2px solid var(--color-accent)", borderRight: "2px solid var(--color-accent)" }} />
          <div style={{ position: "absolute", bottom: 0, left: 0, width: "40px", height: "40px", borderBottom: "2px solid var(--color-accent)", borderLeft: "2px solid var(--color-accent)" }} />
          <div style={{ position: "absolute", bottom: 0, right: 0, width: "40px", height: "40px", borderBottom: "2px solid var(--color-accent)", borderRight: "2px solid var(--color-accent)" }} />

          <div className="tag-pill" style={{ marginBottom: "20px" }}>Хотите своё?</div>
          <h3 style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "clamp(24px, 3.5vw, 42px)",
            color: "#f5f0e8", marginBottom: "16px", lineHeight: 1.2,
          }}>
            Создадим проект с нуля —
            <br /><span className="gold-text">строго под ваши желания</span>
          </h3>
          <p style={{
            color: "rgba(245,240,232,0.5)", fontSize: "16px",
            maxWidth: "500px", margin: "0 auto 36px", lineHeight: 1.7,
          }}>
            Технический специалист разработает дом под ваш участок,
            бюджет и стиль жизни — с нуля или на основе понравившегося проекта.
          </p>
          <div style={{ display: "flex", gap: "16px", justifyContent: "center", flexWrap: "wrap" }}>
            <a href="#contact" className="btn-gold"
              onClick={(e) => { e.preventDefault(); document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" }); }}>
              Обсудить проект
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M5 12h14M12 5l7 7-7 7"/>
              </svg>
            </a>
            <a href="https://zodkam.ru/works/" target="_blank" rel="noopener noreferrer" className="btn-outline">
              Посмотреть реализованные
            </a>
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 900px) {
          .mosaic-grid { grid-template-columns: 1fr 1fr !important; }
          .mosaic-grid > div { grid-column: span 1 !important; grid-row: span 1 !important; min-height: 220px !important; }
        }
        @media (max-width: 500px) {
          .mosaic-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </section>
  );
}

function ProjectInfo({ p, small }: { p: typeof projects[0]; small?: boolean }) {
  return (
    <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, padding: small ? "16px" : "28px" }}>
      <div style={{
        fontSize: small ? "9px" : "11px",
        color: "var(--color-accent)",
        fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "4px",
      }}>{p.type} · {p.rooms}</div>
      <div style={{
        fontSize: small ? "16px" : "22px", fontWeight: 700,
        color: "#f5f0e8", fontFamily: "'Playfair Display', serif", marginBottom: "2px",
      }}>{p.name}</div>
      <div style={{ fontSize: small ? "12px" : "14px", color: "rgba(245,240,232,0.55)" }}>{p.area}</div>
    </div>
  );
}
