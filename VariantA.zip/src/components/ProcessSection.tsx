"use client";

import { useEffect, useRef, useState } from "react";

const steps = [
  { num: "01", title: "Консультация", desc: "Бесплатная встреча в офисе. Показываем 500+ реализованных объектов, обсуждаем ваш проект и бюджет.", icon: "💬", time: "1 день", color: "#c8a45a" },
  { num: "02", title: "Проект", desc: "Подбираем или создаём проект. Вы утверждаете каждую деталь. 3D-визуализация включена.", icon: "📐", time: "3–7 дней", color: "#d4b068" },
  { num: "03", title: "Договор", desc: "Фиксируем стоимость, сроки и гарантии. Цена в договоре = цена при сдаче. Никаких сюрпризов.", icon: "📋", time: "1–2 дня", color: "#e0be82" },
  { num: "04", title: "Строительство", desc: "Собственная бригада и материалы. Онлайн-отчёты с объекта каждую неделю.", icon: "🏗️", time: "3–6 мес.", color: "#e8ca90" },
  { num: "05", title: "Ключи!", desc: "Финальный контроль качества. Подписываем акт. Вручаем ключи. Гарантия 5 лет начинается здесь.", icon: "🔑", time: "1 день", color: "#c8a45a" },
];

export default function ProcessSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [activeStep, setActiveStep] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add("visible"); });
    }, { threshold: 0.05 });
    sectionRef.current?.querySelectorAll(".reveal-up").forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  // Auto-advance steps
  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          setActiveStep((s) => (s + 1) % steps.length);
          return 0;
        }
        return prev + 2;
      });
    }, 60);
    return () => clearInterval(interval);
  }, []);

  return (
    <section
      ref={sectionRef}
      id="process"
      style={{ padding: "130px 0", background: "var(--color-bg)", position: "relative", overflow: "hidden" }}
    >
      <div className="grid-decoration" />

      {/* Big watermark */}
      <div style={{
        position: "absolute", top: "50%", left: "50%",
        transform: "translate(-50%, -50%)",
        fontSize: "clamp(80px, 18vw, 240px)",
        fontWeight: 900, fontFamily: "'Playfair Display', serif",
        color: "rgba(200,164,90,0.025)",
        letterSpacing: "-0.05em", whiteSpace: "nowrap",
        userSelect: "none", pointerEvents: "none",
      }}>ЗОДЧИЙ</div>

      {/* Glow */}
      <div className="glow-orb" style={{
        width: "600px", height: "600px",
        background: "radial-gradient(circle, rgba(200,164,90,0.05) 0%, transparent 70%)",
        bottom: "-10%", right: "-10%",
      }} />

      <div style={{ maxWidth: "1400px", margin: "0 auto", padding: "0 24px", position: "relative" }}>

        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: "80px" }} className="reveal-up">
          <div className="tag-pill" style={{ marginBottom: "16px" }}>Как мы работаем</div>
          <h2 style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "clamp(30px, 4.5vw, 58px)",
            fontWeight: 700, color: "#f5f0e8", lineHeight: 1.08,
          }}>
            5 шагов к
            <br /><span className="gold-text">дому вашей мечты</span>
          </h2>
        </div>

        {/* Interactive stepper */}
        <div style={{
          display: "grid", gridTemplateColumns: "1fr 1fr",
          gap: "80px", alignItems: "center",
        }} className="process-grid reveal-up">

          {/* Left: step list */}
          <div style={{ display: "flex", flexDirection: "column", gap: "3px" }}>
            {steps.map((step, i) => (
              <div
                key={i}
                onClick={() => { setActiveStep(i); setProgress(0); }}
                style={{
                  padding: "24px 28px",
                  cursor: "none",
                  background: i === activeStep ? "rgba(200,164,90,0.07)" : "rgba(255,255,255,0.015)",
                  border: `1px solid ${i === activeStep ? "rgba(200,164,90,0.35)" : "rgba(255,255,255,0.04)"}`,
                  transition: "all 0.35s ease",
                  position: "relative",
                  overflow: "hidden",
                }}
              >
                {/* Progress bar for active */}
                {i === activeStep && (
                  <div style={{
                    position: "absolute", bottom: 0, left: 0,
                    height: "2px",
                    width: `${progress}%`,
                    background: "linear-gradient(90deg, var(--color-accent), var(--color-accent-light))",
                    transition: "width 0.06s linear",
                    boxShadow: "0 0 10px rgba(200,164,90,0.8)",
                  }} />
                )}

                <div style={{ display: "flex", alignItems: "center", gap: "20px" }}>
                  <div style={{
                    width: "52px", height: "52px", flexShrink: 0,
                    border: `1px solid ${i === activeStep ? "var(--color-accent)" : "rgba(200,164,90,0.2)"}`,
                    background: i === activeStep ? "rgba(200,164,90,0.15)" : "rgba(255,255,255,0.02)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    transition: "all 0.3s ease",
                  }}>
                    <span style={{ fontSize: "22px" }}>{step.icon}</span>
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "4px" }}>
                      <span style={{
                        fontSize: "11px", fontWeight: 700,
                        color: i === activeStep ? "var(--color-accent)" : "rgba(200,164,90,0.4)",
                        letterSpacing: "0.15em", textTransform: "uppercase",
                      }}>{step.num}</span>
                      <span style={{
                        fontSize: "16px", fontWeight: 700,
                        color: i === activeStep ? "#f5f0e8" : "rgba(245,240,232,0.5)",
                        transition: "color 0.3s ease",
                      }}>{step.title}</span>
                    </div>
                    {i === activeStep && (
                      <p style={{ fontSize: "13px", color: "rgba(245,240,232,0.55)", lineHeight: 1.65 }}>
                        {step.desc}
                      </p>
                    )}
                  </div>
                  <div style={{
                    padding: "4px 10px",
                    background: i === activeStep ? "rgba(200,164,90,0.15)" : "transparent",
                    border: `1px solid ${i === activeStep ? "rgba(200,164,90,0.3)" : "transparent"}`,
                    color: i === activeStep ? "var(--color-accent)" : "rgba(200,164,90,0.3)",
                    fontSize: "10px", fontWeight: 600,
                    letterSpacing: "0.08em", textTransform: "uppercase",
                    transition: "all 0.3s ease", flexShrink: 0,
                  }}>{step.time}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Right: active step visual */}
          <div style={{ position: "relative" }}>
            <div style={{
              position: "relative",
              background: "rgba(200,164,90,0.04)",
              border: "1px solid rgba(200,164,90,0.15)",
              padding: "64px 48px",
              overflow: "hidden",
              minHeight: "440px",
              display: "flex", flexDirection: "column", justifyContent: "center",
            }}>
              {/* Big step icon */}
              <div style={{
                fontSize: "80px", marginBottom: "32px",
                transition: "transform 0.5s ease, opacity 0.5s ease",
                filter: "drop-shadow(0 0 20px rgba(200,164,90,0.3))",
              }}>
                {steps[activeStep].icon}
              </div>

              <div style={{
                fontSize: "12px", fontWeight: 700,
                color: "var(--color-accent)", letterSpacing: "0.2em",
                textTransform: "uppercase", marginBottom: "16px",
              }}>
                Шаг {steps[activeStep].num} / 05
              </div>

              <h3 style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: "36px", fontWeight: 700, color: "#f5f0e8",
                marginBottom: "20px", lineHeight: 1.2,
              }}>{steps[activeStep].title}</h3>

              <p style={{
                fontSize: "16px", color: "rgba(245,240,232,0.6)",
                lineHeight: 1.75, marginBottom: "36px",
              }}>{steps[activeStep].desc}</p>

              <div style={{
                padding: "16px 24px",
                background: "rgba(200,164,90,0.08)",
                border: "1px solid rgba(200,164,90,0.2)",
                display: "inline-flex", alignItems: "center", gap: "10px",
                alignSelf: "flex-start",
              }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--color-accent)" strokeWidth="2">
                  <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
                </svg>
                <span style={{ fontSize: "13px", color: "var(--color-accent)", fontWeight: 600 }}>
                  Срок: {steps[activeStep].time}
                </span>
              </div>

              {/* Decorative corners */}
              <div style={{ position: "absolute", top: 0, left: 0, width: "30px", height: "30px", borderTop: "2px solid var(--color-accent)", borderLeft: "2px solid var(--color-accent)" }} />
              <div style={{ position: "absolute", bottom: 0, right: 0, width: "30px", height: "30px", borderBottom: "2px solid var(--color-accent)", borderRight: "2px solid var(--color-accent)" }} />

              {/* Big step number watermark */}
              <div style={{
                position: "absolute", bottom: "20px", right: "24px",
                fontSize: "80px", fontWeight: 900, fontFamily: "'Playfair Display', serif",
                color: "rgba(200,164,90,0.05)", lineHeight: 1,
                userSelect: "none", pointerEvents: "none",
              }}>{steps[activeStep].num}</div>
            </div>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="reveal-up" style={{ textAlign: "center", marginTop: "72px" }}>
          <p style={{ color: "rgba(245,240,232,0.5)", fontSize: "16px", marginBottom: "28px" }}>
            Первая консультация <strong style={{ color: "#f5f0e8" }}>бесплатна</strong> и ни к чему не обязывает
          </p>
          <div style={{ display: "flex", gap: "16px", justifyContent: "center", flexWrap: "wrap" }}>
            <a href="#contact" className="btn-gold"
              onClick={(e) => { e.preventDefault(); document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" }); }}>
              Записаться на консультацию
            </a>
            <a href="tel:+79992229292" className="btn-outline">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 1.27h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.9a16 16 0 0 0 5.28 5.28l1.99-1.99a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>
              </svg>
              Позвонить сейчас
            </a>
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 900px) {
          .process-grid { grid-template-columns: 1fr !important; gap: 40px !important; }
        }
      `}</style>
    </section>
  );
}
